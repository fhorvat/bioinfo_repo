#!/bin/bash
# ----------------Loading variables------------------- #
# set experiment
EXPERIMENT=mESC_MosIR

# base path
BASE_PATH=/common/WORK/fhorvat/Projekti/Svoboda/RNAi.Eliska/mESC_MosIR/datasets/Jul_2018

# mapped and documentation
MAPPED_PATH=${BASE_PATH}/Data/Mapped/STAR_mm10
DOCUMENTATION_PATH=${BASE_PATH}/Data/Documentation

# genome and features
GENOME_PATH=/common/DB/genome_reference/mouse/mm10.GRCm38.GCA_000001635.2
FEATURES_COORDINATES=${GENOME_PATH}/miRBase.22.mm10.20181605.gff3
FEATURES_NAME=${FEATURES_COORDINATES##/*/}
FEATURES_NAME=${FEATURES_NAME%.gff3}

# other
SINGLE_END=TRUE
THREADS=1
GROUPING_VARIABLES="genotype transfection"
RESULTS_GROUPS=""
PROTEIN_CODING_ONLY="no"
EXPLORATORY_ANALYSIS="yes"
INTERACTIVE_PLOTS="yes"
