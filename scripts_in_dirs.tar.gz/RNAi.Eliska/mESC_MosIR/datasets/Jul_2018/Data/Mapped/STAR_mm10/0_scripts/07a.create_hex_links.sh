#/bin/bash

# ----------------Loading variables------------------- #
EXPERIMENT=mESC_MosIR

HEX_PATH=~/public_html/Svoboda/bw_tracks/in_house/mESC_MosIR.Jul_2019
LOBSANG_PATH=/common-lobsang/WORK/fhorvat/Projekti/Svoboda/RNAi.Eliska/mESC_MosIR/datasets/Jul_2018/Data/Mapped/STAR_mm10

# ----------------Commands------------------- #
# create links
mkdir -p $HEX_PATH
cd $HEX_PATH
find ${LOBSANG_PATH}/6_tracks -name "*.bw" -exec ln -s {} $HEX_PATH \;
find $LOBSANG_PATH -name "*.bam*" -exec ln -s {} $HEX_PATH \;

# getURL
~/bin/getURL | sed '1d' > log.tracks_URL.txt
sed -i '1d' log.tracks_URL.txt
chmod 744 log.tracks_URL.txt
