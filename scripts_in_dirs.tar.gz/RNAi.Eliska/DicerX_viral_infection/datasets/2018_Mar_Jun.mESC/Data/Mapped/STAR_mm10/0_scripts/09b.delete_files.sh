#/bin/bash
# ----------------Commands------------------- #
# delete all in mapped and unmapped directories
rm \
./1_mapped/* \
./2_unmapped/* \
